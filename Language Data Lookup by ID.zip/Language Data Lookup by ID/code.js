// When button1 is clicked, switch to screen2
onEvent("Button1", "click", function() {
  setScreen("screen2");
});

// When button2 is clicked, switch back to screen1
onEvent("Button2", "click", function() {
  setScreen("screen1");
});
// When WHO button is clicked, open WHO website in a new tab
onEvent("Languages_button", "click", function() {
  open("https://www.ethnologue.com/browse/names/", "_blank");
});

// List of top world languages
var languages = [
  {id: 1, rank: 1, name: "Mandarin Chinese", speakers: 918, percentage: 11.922, family: "Sino-Tibetan", branch: "Sinitic"},
  {id: 2, rank: 2, name: "Spanish", speakers: 480, percentage: 5.994, family: "Indo-European", branch: "Romance"},
  {id: 3, rank: 3, name: "English", speakers: 379, percentage: 4.922, family: "Indo-European", branch: "Germanic"},
  {id: 4, rank: 4, name: "Hindi", speakers: 341, percentage: 4.429, family: "Indo-European", branch: "Indo-Aryan"},
  ({id: 5, rank: 5, name: "Bengali", speakers: 228, percentage: 2.961, family: "Indo-European", branch: "Indo-Aryan"}),
  {id: 6, rank: 6, name: "Portuguese", speakers: 221, percentage: 2.869, family: "Indo-European", branch: "Romance" },
  {id: 7, rank: 7, name: "Russian", speakers: 154, percentage: 2.000, family: "Indo-European", branch: "Slavic" },
  {id: 8, rank: 8, name: "Japanese", speakers: 128, percentage: 1.669, family: "Japonic", branch: "Japanese" },
  {id: 9, rank: 9, name: "Punjabi", speakers: 125, percentage: 1.622, family: "Indo-European", branch: "Indo-Aryan" },
  {id: 10, rank: 10, name: "Marathi", speakers: 99, percentage: 1.285, family: "Indo-European", branch: "Indo-Aryan" },
  ({id: 11, rank: 11, name: "Telugu", speakers: 96, percentage: 1.247, family: "Dravidian", branch: "South-Central Dravidian" }),
  {id: 12, rank: 12, name: "Turkish", speakers: 88, percentage: 1.143, family: "Turkic", branch: "Oghuz" },
  {id: 13, rank: 13, name: "Wu Chinese (Shanghainese)", speakers: 85, percentage: 1.104, family: "Sino-Tibetan", branch: "Sinitic" },
  {id: 14, rank: 14, name: "Korean", speakers: 81, percentage: 1.052, family: "Koreanic", branch: "Korean" },
  {id: 15, rank: 15, name: "French", speakers: 77, percentage: 0.999, family: "Indo-European", branch: "Romance" },
  {id: 16, rank: 16, name: "German", speakers: 76, percentage: 0.986, family: "Indo-European", branch: "Germanic" },
  {id: 17, rank: 17, name: "Vietnamese", speakers: 76, percentage: 0.986, family: "Austroasiatic", branch: "Vietic" },
  {id: 18, rank: 18, name: "Tamil", speakers: 75, percentage: 0.974, family: "Dravidian", branch: "Southern Dravidian" },
  {id: 19, rank: 19, name: "Yue Chinese (Cantonese)", speakers: 73, percentage: 0.948, family: "Sino-Tibetan", branch: "Sinitic" },
  {id: 20, rank: 20, name: "Urdu", speakers: 70, percentage: 0.910, family: "Indo-European", branch: "Indo-Aryan" }
];


// Function to find a language by rank or name
function findLanguage(query) {
  query = query.toString(); // Convert query to a string
  
  for (var i = 0; i < languages.length; i++) {
    if (languages[i].rank == query || languages[i].name.toLowerCase() === query.toLowerCase()) {
      return languages[i];
    }
  }
  return null; // Return null if no match found
}


// Event listener for search button click
onEvent("searchButton", "click", function() {
  var userInput = getText("searchInput");
  var parsedInput = parseInt(userInput); // Try to convert input to a number

  var result = findLanguage(parsedInput) || findLanguage(userInput); // Search by number or text

  if (result) {
    setText("outputLabel", 
      "Language: " + result.name + 
      "\nSpeakers: " + result.speakers + "M" + 
      "\nFamily: " + result.family + 
      "\nBranch: " + result.branch
    );
  } else {
    setText("outputLabel", "Language not found. Try again!");
  }
});